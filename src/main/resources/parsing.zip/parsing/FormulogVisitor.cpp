
// Generated from Formulog.g4 by ANTLR 4.7.1


#include "FormulogVisitor.h"


