
// Generated from Formulog.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "FormulogListener.h"


/**
 * This class provides an empty implementation of FormulogListener,
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
class  FormulogBaseListener : public FormulogListener {
public:

  virtual void enterProg(FormulogParser::ProgContext * /*ctx*/) override { }
  virtual void exitProg(FormulogParser::ProgContext * /*ctx*/) override { }

  virtual void enterTsvFile(FormulogParser::TsvFileContext * /*ctx*/) override { }
  virtual void exitTsvFile(FormulogParser::TsvFileContext * /*ctx*/) override { }

  virtual void enterTabSeparatedTermLine(FormulogParser::TabSeparatedTermLineContext * /*ctx*/) override { }
  virtual void exitTabSeparatedTermLine(FormulogParser::TabSeparatedTermLineContext * /*ctx*/) override { }

  virtual void enterFunDecl(FormulogParser::FunDeclContext * /*ctx*/) override { }
  virtual void exitFunDecl(FormulogParser::FunDeclContext * /*ctx*/) override { }

  virtual void enterRelDecl(FormulogParser::RelDeclContext * /*ctx*/) override { }
  virtual void exitRelDecl(FormulogParser::RelDeclContext * /*ctx*/) override { }

  virtual void enterTypeAlias(FormulogParser::TypeAliasContext * /*ctx*/) override { }
  virtual void exitTypeAlias(FormulogParser::TypeAliasContext * /*ctx*/) override { }

  virtual void enterTypeDecl(FormulogParser::TypeDeclContext * /*ctx*/) override { }
  virtual void exitTypeDecl(FormulogParser::TypeDeclContext * /*ctx*/) override { }

  virtual void enterUninterpFunDecl(FormulogParser::UninterpFunDeclContext * /*ctx*/) override { }
  virtual void exitUninterpFunDecl(FormulogParser::UninterpFunDeclContext * /*ctx*/) override { }

  virtual void enterUninterpSortDecl(FormulogParser::UninterpSortDeclContext * /*ctx*/) override { }
  virtual void exitUninterpSortDecl(FormulogParser::UninterpSortDeclContext * /*ctx*/) override { }

  virtual void enterFunDefLHS(FormulogParser::FunDefLHSContext * /*ctx*/) override { }
  virtual void exitFunDefLHS(FormulogParser::FunDefLHSContext * /*ctx*/) override { }

  virtual void enterFunDefs(FormulogParser::FunDefsContext * /*ctx*/) override { }
  virtual void exitFunDefs(FormulogParser::FunDefsContext * /*ctx*/) override { }

  virtual void enterConstructorType(FormulogParser::ConstructorTypeContext * /*ctx*/) override { }
  virtual void exitConstructorType(FormulogParser::ConstructorTypeContext * /*ctx*/) override { }

  virtual void enterVarTypeList(FormulogParser::VarTypeListContext * /*ctx*/) override { }
  virtual void exitVarTypeList(FormulogParser::VarTypeListContext * /*ctx*/) override { }

  virtual void enterTypeList(FormulogParser::TypeListContext * /*ctx*/) override { }
  virtual void exitTypeList(FormulogParser::TypeListContext * /*ctx*/) override { }

  virtual void enterTypeVar(FormulogParser::TypeVarContext * /*ctx*/) override { }
  virtual void exitTypeVar(FormulogParser::TypeVarContext * /*ctx*/) override { }

  virtual void enterParenType(FormulogParser::ParenTypeContext * /*ctx*/) override { }
  virtual void exitParenType(FormulogParser::ParenTypeContext * /*ctx*/) override { }

  virtual void enterTypeRef(FormulogParser::TypeRefContext * /*ctx*/) override { }
  virtual void exitTypeRef(FormulogParser::TypeRefContext * /*ctx*/) override { }

  virtual void enterTupleType(FormulogParser::TupleTypeContext * /*ctx*/) override { }
  virtual void exitTupleType(FormulogParser::TupleTypeContext * /*ctx*/) override { }

  virtual void enterParameterList(FormulogParser::ParameterListContext * /*ctx*/) override { }
  virtual void exitParameterList(FormulogParser::ParameterListContext * /*ctx*/) override { }

  virtual void enterWildCardParam(FormulogParser::WildCardParamContext * /*ctx*/) override { }
  virtual void exitWildCardParam(FormulogParser::WildCardParamContext * /*ctx*/) override { }

  virtual void enterTypeParam(FormulogParser::TypeParamContext * /*ctx*/) override { }
  virtual void exitTypeParam(FormulogParser::TypeParamContext * /*ctx*/) override { }

  virtual void enterIntParam(FormulogParser::IntParamContext * /*ctx*/) override { }
  virtual void exitIntParam(FormulogParser::IntParamContext * /*ctx*/) override { }

  virtual void enterTypeDefLHS(FormulogParser::TypeDefLHSContext * /*ctx*/) override { }
  virtual void exitTypeDefLHS(FormulogParser::TypeDefLHSContext * /*ctx*/) override { }

  virtual void enterTypeDefRHS(FormulogParser::TypeDefRHSContext * /*ctx*/) override { }
  virtual void exitTypeDefRHS(FormulogParser::TypeDefRHSContext * /*ctx*/) override { }

  virtual void enterAdtDef(FormulogParser::AdtDefContext * /*ctx*/) override { }
  virtual void exitAdtDef(FormulogParser::AdtDefContext * /*ctx*/) override { }

  virtual void enterRecordDef(FormulogParser::RecordDefContext * /*ctx*/) override { }
  virtual void exitRecordDef(FormulogParser::RecordDefContext * /*ctx*/) override { }

  virtual void enterRecordEntryDef(FormulogParser::RecordEntryDefContext * /*ctx*/) override { }
  virtual void exitRecordEntryDef(FormulogParser::RecordEntryDefContext * /*ctx*/) override { }

  virtual void enterAnnotation(FormulogParser::AnnotationContext * /*ctx*/) override { }
  virtual void exitAnnotation(FormulogParser::AnnotationContext * /*ctx*/) override { }

  virtual void enterClauseStmt(FormulogParser::ClauseStmtContext * /*ctx*/) override { }
  virtual void exitClauseStmt(FormulogParser::ClauseStmtContext * /*ctx*/) override { }

  virtual void enterFactStmt(FormulogParser::FactStmtContext * /*ctx*/) override { }
  virtual void exitFactStmt(FormulogParser::FactStmtContext * /*ctx*/) override { }

  virtual void enterQueryStmt(FormulogParser::QueryStmtContext * /*ctx*/) override { }
  virtual void exitQueryStmt(FormulogParser::QueryStmtContext * /*ctx*/) override { }

  virtual void enterClause(FormulogParser::ClauseContext * /*ctx*/) override { }
  virtual void exitClause(FormulogParser::ClauseContext * /*ctx*/) override { }

  virtual void enterFact(FormulogParser::FactContext * /*ctx*/) override { }
  virtual void exitFact(FormulogParser::FactContext * /*ctx*/) override { }

  virtual void enterQuery(FormulogParser::QueryContext * /*ctx*/) override { }
  virtual void exitQuery(FormulogParser::QueryContext * /*ctx*/) override { }

  virtual void enterPredicate(FormulogParser::PredicateContext * /*ctx*/) override { }
  virtual void exitPredicate(FormulogParser::PredicateContext * /*ctx*/) override { }

  virtual void enterIndexedFunctor(FormulogParser::IndexedFunctorContext * /*ctx*/) override { }
  virtual void exitIndexedFunctor(FormulogParser::IndexedFunctorContext * /*ctx*/) override { }

  virtual void enterTermArgs(FormulogParser::TermArgsContext * /*ctx*/) override { }
  virtual void exitTermArgs(FormulogParser::TermArgsContext * /*ctx*/) override { }

  virtual void enterQuantifiedFormula(FormulogParser::QuantifiedFormulaContext * /*ctx*/) override { }
  virtual void exitQuantifiedFormula(FormulogParser::QuantifiedFormulaContext * /*ctx*/) override { }

  virtual void enterBinopTerm(FormulogParser::BinopTermContext * /*ctx*/) override { }
  virtual void exitBinopTerm(FormulogParser::BinopTermContext * /*ctx*/) override { }

  virtual void enterMatchExpr(FormulogParser::MatchExprContext * /*ctx*/) override { }
  virtual void exitMatchExpr(FormulogParser::MatchExprContext * /*ctx*/) override { }

  virtual void enterFunctorTerm(FormulogParser::FunctorTermContext * /*ctx*/) override { }
  virtual void exitFunctorTerm(FormulogParser::FunctorTermContext * /*ctx*/) override { }

  virtual void enterI32Term(FormulogParser::I32TermContext * /*ctx*/) override { }
  virtual void exitI32Term(FormulogParser::I32TermContext * /*ctx*/) override { }

  virtual void enterNotFormula(FormulogParser::NotFormulaContext * /*ctx*/) override { }
  virtual void exitNotFormula(FormulogParser::NotFormulaContext * /*ctx*/) override { }

  virtual void enterLetExpr(FormulogParser::LetExprContext * /*ctx*/) override { }
  virtual void exitLetExpr(FormulogParser::LetExprContext * /*ctx*/) override { }

  virtual void enterFloatTerm(FormulogParser::FloatTermContext * /*ctx*/) override { }
  virtual void exitFloatTerm(FormulogParser::FloatTermContext * /*ctx*/) override { }

  virtual void enterRecordTerm(FormulogParser::RecordTermContext * /*ctx*/) override { }
  virtual void exitRecordTerm(FormulogParser::RecordTermContext * /*ctx*/) override { }

  virtual void enterLetFormula(FormulogParser::LetFormulaContext * /*ctx*/) override { }
  virtual void exitLetFormula(FormulogParser::LetFormulaContext * /*ctx*/) override { }

  virtual void enterUnopTerm(FormulogParser::UnopTermContext * /*ctx*/) override { }
  virtual void exitUnopTerm(FormulogParser::UnopTermContext * /*ctx*/) override { }

  virtual void enterIfExpr(FormulogParser::IfExprContext * /*ctx*/) override { }
  virtual void exitIfExpr(FormulogParser::IfExprContext * /*ctx*/) override { }

  virtual void enterHoleTerm(FormulogParser::HoleTermContext * /*ctx*/) override { }
  virtual void exitHoleTerm(FormulogParser::HoleTermContext * /*ctx*/) override { }

  virtual void enterListTerm(FormulogParser::ListTermContext * /*ctx*/) override { }
  virtual void exitListTerm(FormulogParser::ListTermContext * /*ctx*/) override { }

  virtual void enterVarTerm(FormulogParser::VarTermContext * /*ctx*/) override { }
  virtual void exitVarTerm(FormulogParser::VarTermContext * /*ctx*/) override { }

  virtual void enterStringTerm(FormulogParser::StringTermContext * /*ctx*/) override { }
  virtual void exitStringTerm(FormulogParser::StringTermContext * /*ctx*/) override { }

  virtual void enterFormulaTerm(FormulogParser::FormulaTermContext * /*ctx*/) override { }
  virtual void exitFormulaTerm(FormulogParser::FormulaTermContext * /*ctx*/) override { }

  virtual void enterConsTerm(FormulogParser::ConsTermContext * /*ctx*/) override { }
  virtual void exitConsTerm(FormulogParser::ConsTermContext * /*ctx*/) override { }

  virtual void enterTermSymFormula(FormulogParser::TermSymFormulaContext * /*ctx*/) override { }
  virtual void exitTermSymFormula(FormulogParser::TermSymFormulaContext * /*ctx*/) override { }

  virtual void enterParensTerm(FormulogParser::ParensTermContext * /*ctx*/) override { }
  virtual void exitParensTerm(FormulogParser::ParensTermContext * /*ctx*/) override { }

  virtual void enterI64Term(FormulogParser::I64TermContext * /*ctx*/) override { }
  virtual void exitI64Term(FormulogParser::I64TermContext * /*ctx*/) override { }

  virtual void enterIteTerm(FormulogParser::IteTermContext * /*ctx*/) override { }
  virtual void exitIteTerm(FormulogParser::IteTermContext * /*ctx*/) override { }

  virtual void enterFoldTerm(FormulogParser::FoldTermContext * /*ctx*/) override { }
  virtual void exitFoldTerm(FormulogParser::FoldTermContext * /*ctx*/) override { }

  virtual void enterSpecialFPTerm(FormulogParser::SpecialFPTermContext * /*ctx*/) override { }
  virtual void exitSpecialFPTerm(FormulogParser::SpecialFPTermContext * /*ctx*/) override { }

  virtual void enterDoubleTerm(FormulogParser::DoubleTermContext * /*ctx*/) override { }
  virtual void exitDoubleTerm(FormulogParser::DoubleTermContext * /*ctx*/) override { }

  virtual void enterLetFunExpr(FormulogParser::LetFunExprContext * /*ctx*/) override { }
  virtual void exitLetFunExpr(FormulogParser::LetFunExprContext * /*ctx*/) override { }

  virtual void enterBinopFormula(FormulogParser::BinopFormulaContext * /*ctx*/) override { }
  virtual void exitBinopFormula(FormulogParser::BinopFormulaContext * /*ctx*/) override { }

  virtual void enterOutermostCtor(FormulogParser::OutermostCtorContext * /*ctx*/) override { }
  virtual void exitOutermostCtor(FormulogParser::OutermostCtorContext * /*ctx*/) override { }

  virtual void enterTupleTerm(FormulogParser::TupleTermContext * /*ctx*/) override { }
  virtual void exitTupleTerm(FormulogParser::TupleTermContext * /*ctx*/) override { }

  virtual void enterRecordUpdateTerm(FormulogParser::RecordUpdateTermContext * /*ctx*/) override { }
  virtual void exitRecordUpdateTerm(FormulogParser::RecordUpdateTermContext * /*ctx*/) override { }

  virtual void enterRecordEntries(FormulogParser::RecordEntriesContext * /*ctx*/) override { }
  virtual void exitRecordEntries(FormulogParser::RecordEntriesContext * /*ctx*/) override { }

  virtual void enterRecordEntry(FormulogParser::RecordEntryContext * /*ctx*/) override { }
  virtual void exitRecordEntry(FormulogParser::RecordEntryContext * /*ctx*/) override { }

  virtual void enterLetBind(FormulogParser::LetBindContext * /*ctx*/) override { }
  virtual void exitLetBind(FormulogParser::LetBindContext * /*ctx*/) override { }

  virtual void enterNonEmptyTermList(FormulogParser::NonEmptyTermListContext * /*ctx*/) override { }
  virtual void exitNonEmptyTermList(FormulogParser::NonEmptyTermListContext * /*ctx*/) override { }

  virtual void enterList(FormulogParser::ListContext * /*ctx*/) override { }
  virtual void exitList(FormulogParser::ListContext * /*ctx*/) override { }

  virtual void enterTuple(FormulogParser::TupleContext * /*ctx*/) override { }
  virtual void exitTuple(FormulogParser::TupleContext * /*ctx*/) override { }

  virtual void enterMatchClause(FormulogParser::MatchClauseContext * /*ctx*/) override { }
  virtual void exitMatchClause(FormulogParser::MatchClauseContext * /*ctx*/) override { }

  virtual void enterPatterns(FormulogParser::PatternsContext * /*ctx*/) override { }
  virtual void exitPatterns(FormulogParser::PatternsContext * /*ctx*/) override { }


  virtual void enterEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void exitEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void visitTerminal(antlr4::tree::TerminalNode * /*node*/) override { }
  virtual void visitErrorNode(antlr4::tree::ErrorNode * /*node*/) override { }

};

