
// Generated from Formulog.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "FormulogParser.h"


/**
 * This interface defines an abstract listener for a parse tree produced by FormulogParser.
 */
class  FormulogListener : public antlr4::tree::ParseTreeListener {
public:

  virtual void enterProg(FormulogParser::ProgContext *ctx) = 0;
  virtual void exitProg(FormulogParser::ProgContext *ctx) = 0;

  virtual void enterTsvFile(FormulogParser::TsvFileContext *ctx) = 0;
  virtual void exitTsvFile(FormulogParser::TsvFileContext *ctx) = 0;

  virtual void enterTabSeparatedTermLine(FormulogParser::TabSeparatedTermLineContext *ctx) = 0;
  virtual void exitTabSeparatedTermLine(FormulogParser::TabSeparatedTermLineContext *ctx) = 0;

  virtual void enterFunDecl(FormulogParser::FunDeclContext *ctx) = 0;
  virtual void exitFunDecl(FormulogParser::FunDeclContext *ctx) = 0;

  virtual void enterRelDecl(FormulogParser::RelDeclContext *ctx) = 0;
  virtual void exitRelDecl(FormulogParser::RelDeclContext *ctx) = 0;

  virtual void enterTypeAlias(FormulogParser::TypeAliasContext *ctx) = 0;
  virtual void exitTypeAlias(FormulogParser::TypeAliasContext *ctx) = 0;

  virtual void enterTypeDecl(FormulogParser::TypeDeclContext *ctx) = 0;
  virtual void exitTypeDecl(FormulogParser::TypeDeclContext *ctx) = 0;

  virtual void enterUninterpFunDecl(FormulogParser::UninterpFunDeclContext *ctx) = 0;
  virtual void exitUninterpFunDecl(FormulogParser::UninterpFunDeclContext *ctx) = 0;

  virtual void enterUninterpSortDecl(FormulogParser::UninterpSortDeclContext *ctx) = 0;
  virtual void exitUninterpSortDecl(FormulogParser::UninterpSortDeclContext *ctx) = 0;

  virtual void enterFunDefLHS(FormulogParser::FunDefLHSContext *ctx) = 0;
  virtual void exitFunDefLHS(FormulogParser::FunDefLHSContext *ctx) = 0;

  virtual void enterFunDefs(FormulogParser::FunDefsContext *ctx) = 0;
  virtual void exitFunDefs(FormulogParser::FunDefsContext *ctx) = 0;

  virtual void enterConstructorType(FormulogParser::ConstructorTypeContext *ctx) = 0;
  virtual void exitConstructorType(FormulogParser::ConstructorTypeContext *ctx) = 0;

  virtual void enterVarTypeList(FormulogParser::VarTypeListContext *ctx) = 0;
  virtual void exitVarTypeList(FormulogParser::VarTypeListContext *ctx) = 0;

  virtual void enterTypeList(FormulogParser::TypeListContext *ctx) = 0;
  virtual void exitTypeList(FormulogParser::TypeListContext *ctx) = 0;

  virtual void enterTypeVar(FormulogParser::TypeVarContext *ctx) = 0;
  virtual void exitTypeVar(FormulogParser::TypeVarContext *ctx) = 0;

  virtual void enterParenType(FormulogParser::ParenTypeContext *ctx) = 0;
  virtual void exitParenType(FormulogParser::ParenTypeContext *ctx) = 0;

  virtual void enterTypeRef(FormulogParser::TypeRefContext *ctx) = 0;
  virtual void exitTypeRef(FormulogParser::TypeRefContext *ctx) = 0;

  virtual void enterTupleType(FormulogParser::TupleTypeContext *ctx) = 0;
  virtual void exitTupleType(FormulogParser::TupleTypeContext *ctx) = 0;

  virtual void enterParameterList(FormulogParser::ParameterListContext *ctx) = 0;
  virtual void exitParameterList(FormulogParser::ParameterListContext *ctx) = 0;

  virtual void enterWildCardParam(FormulogParser::WildCardParamContext *ctx) = 0;
  virtual void exitWildCardParam(FormulogParser::WildCardParamContext *ctx) = 0;

  virtual void enterTypeParam(FormulogParser::TypeParamContext *ctx) = 0;
  virtual void exitTypeParam(FormulogParser::TypeParamContext *ctx) = 0;

  virtual void enterIntParam(FormulogParser::IntParamContext *ctx) = 0;
  virtual void exitIntParam(FormulogParser::IntParamContext *ctx) = 0;

  virtual void enterTypeDefLHS(FormulogParser::TypeDefLHSContext *ctx) = 0;
  virtual void exitTypeDefLHS(FormulogParser::TypeDefLHSContext *ctx) = 0;

  virtual void enterTypeDefRHS(FormulogParser::TypeDefRHSContext *ctx) = 0;
  virtual void exitTypeDefRHS(FormulogParser::TypeDefRHSContext *ctx) = 0;

  virtual void enterAdtDef(FormulogParser::AdtDefContext *ctx) = 0;
  virtual void exitAdtDef(FormulogParser::AdtDefContext *ctx) = 0;

  virtual void enterRecordDef(FormulogParser::RecordDefContext *ctx) = 0;
  virtual void exitRecordDef(FormulogParser::RecordDefContext *ctx) = 0;

  virtual void enterRecordEntryDef(FormulogParser::RecordEntryDefContext *ctx) = 0;
  virtual void exitRecordEntryDef(FormulogParser::RecordEntryDefContext *ctx) = 0;

  virtual void enterAnnotation(FormulogParser::AnnotationContext *ctx) = 0;
  virtual void exitAnnotation(FormulogParser::AnnotationContext *ctx) = 0;

  virtual void enterClauseStmt(FormulogParser::ClauseStmtContext *ctx) = 0;
  virtual void exitClauseStmt(FormulogParser::ClauseStmtContext *ctx) = 0;

  virtual void enterFactStmt(FormulogParser::FactStmtContext *ctx) = 0;
  virtual void exitFactStmt(FormulogParser::FactStmtContext *ctx) = 0;

  virtual void enterQueryStmt(FormulogParser::QueryStmtContext *ctx) = 0;
  virtual void exitQueryStmt(FormulogParser::QueryStmtContext *ctx) = 0;

  virtual void enterClause(FormulogParser::ClauseContext *ctx) = 0;
  virtual void exitClause(FormulogParser::ClauseContext *ctx) = 0;

  virtual void enterFact(FormulogParser::FactContext *ctx) = 0;
  virtual void exitFact(FormulogParser::FactContext *ctx) = 0;

  virtual void enterQuery(FormulogParser::QueryContext *ctx) = 0;
  virtual void exitQuery(FormulogParser::QueryContext *ctx) = 0;

  virtual void enterPredicate(FormulogParser::PredicateContext *ctx) = 0;
  virtual void exitPredicate(FormulogParser::PredicateContext *ctx) = 0;

  virtual void enterIndexedFunctor(FormulogParser::IndexedFunctorContext *ctx) = 0;
  virtual void exitIndexedFunctor(FormulogParser::IndexedFunctorContext *ctx) = 0;

  virtual void enterTermArgs(FormulogParser::TermArgsContext *ctx) = 0;
  virtual void exitTermArgs(FormulogParser::TermArgsContext *ctx) = 0;

  virtual void enterQuantifiedFormula(FormulogParser::QuantifiedFormulaContext *ctx) = 0;
  virtual void exitQuantifiedFormula(FormulogParser::QuantifiedFormulaContext *ctx) = 0;

  virtual void enterBinopTerm(FormulogParser::BinopTermContext *ctx) = 0;
  virtual void exitBinopTerm(FormulogParser::BinopTermContext *ctx) = 0;

  virtual void enterMatchExpr(FormulogParser::MatchExprContext *ctx) = 0;
  virtual void exitMatchExpr(FormulogParser::MatchExprContext *ctx) = 0;

  virtual void enterFunctorTerm(FormulogParser::FunctorTermContext *ctx) = 0;
  virtual void exitFunctorTerm(FormulogParser::FunctorTermContext *ctx) = 0;

  virtual void enterI32Term(FormulogParser::I32TermContext *ctx) = 0;
  virtual void exitI32Term(FormulogParser::I32TermContext *ctx) = 0;

  virtual void enterNotFormula(FormulogParser::NotFormulaContext *ctx) = 0;
  virtual void exitNotFormula(FormulogParser::NotFormulaContext *ctx) = 0;

  virtual void enterLetExpr(FormulogParser::LetExprContext *ctx) = 0;
  virtual void exitLetExpr(FormulogParser::LetExprContext *ctx) = 0;

  virtual void enterFloatTerm(FormulogParser::FloatTermContext *ctx) = 0;
  virtual void exitFloatTerm(FormulogParser::FloatTermContext *ctx) = 0;

  virtual void enterRecordTerm(FormulogParser::RecordTermContext *ctx) = 0;
  virtual void exitRecordTerm(FormulogParser::RecordTermContext *ctx) = 0;

  virtual void enterLetFormula(FormulogParser::LetFormulaContext *ctx) = 0;
  virtual void exitLetFormula(FormulogParser::LetFormulaContext *ctx) = 0;

  virtual void enterUnopTerm(FormulogParser::UnopTermContext *ctx) = 0;
  virtual void exitUnopTerm(FormulogParser::UnopTermContext *ctx) = 0;

  virtual void enterIfExpr(FormulogParser::IfExprContext *ctx) = 0;
  virtual void exitIfExpr(FormulogParser::IfExprContext *ctx) = 0;

  virtual void enterHoleTerm(FormulogParser::HoleTermContext *ctx) = 0;
  virtual void exitHoleTerm(FormulogParser::HoleTermContext *ctx) = 0;

  virtual void enterListTerm(FormulogParser::ListTermContext *ctx) = 0;
  virtual void exitListTerm(FormulogParser::ListTermContext *ctx) = 0;

  virtual void enterVarTerm(FormulogParser::VarTermContext *ctx) = 0;
  virtual void exitVarTerm(FormulogParser::VarTermContext *ctx) = 0;

  virtual void enterStringTerm(FormulogParser::StringTermContext *ctx) = 0;
  virtual void exitStringTerm(FormulogParser::StringTermContext *ctx) = 0;

  virtual void enterFormulaTerm(FormulogParser::FormulaTermContext *ctx) = 0;
  virtual void exitFormulaTerm(FormulogParser::FormulaTermContext *ctx) = 0;

  virtual void enterConsTerm(FormulogParser::ConsTermContext *ctx) = 0;
  virtual void exitConsTerm(FormulogParser::ConsTermContext *ctx) = 0;

  virtual void enterTermSymFormula(FormulogParser::TermSymFormulaContext *ctx) = 0;
  virtual void exitTermSymFormula(FormulogParser::TermSymFormulaContext *ctx) = 0;

  virtual void enterParensTerm(FormulogParser::ParensTermContext *ctx) = 0;
  virtual void exitParensTerm(FormulogParser::ParensTermContext *ctx) = 0;

  virtual void enterI64Term(FormulogParser::I64TermContext *ctx) = 0;
  virtual void exitI64Term(FormulogParser::I64TermContext *ctx) = 0;

  virtual void enterIteTerm(FormulogParser::IteTermContext *ctx) = 0;
  virtual void exitIteTerm(FormulogParser::IteTermContext *ctx) = 0;

  virtual void enterFoldTerm(FormulogParser::FoldTermContext *ctx) = 0;
  virtual void exitFoldTerm(FormulogParser::FoldTermContext *ctx) = 0;

  virtual void enterSpecialFPTerm(FormulogParser::SpecialFPTermContext *ctx) = 0;
  virtual void exitSpecialFPTerm(FormulogParser::SpecialFPTermContext *ctx) = 0;

  virtual void enterDoubleTerm(FormulogParser::DoubleTermContext *ctx) = 0;
  virtual void exitDoubleTerm(FormulogParser::DoubleTermContext *ctx) = 0;

  virtual void enterLetFunExpr(FormulogParser::LetFunExprContext *ctx) = 0;
  virtual void exitLetFunExpr(FormulogParser::LetFunExprContext *ctx) = 0;

  virtual void enterBinopFormula(FormulogParser::BinopFormulaContext *ctx) = 0;
  virtual void exitBinopFormula(FormulogParser::BinopFormulaContext *ctx) = 0;

  virtual void enterOutermostCtor(FormulogParser::OutermostCtorContext *ctx) = 0;
  virtual void exitOutermostCtor(FormulogParser::OutermostCtorContext *ctx) = 0;

  virtual void enterTupleTerm(FormulogParser::TupleTermContext *ctx) = 0;
  virtual void exitTupleTerm(FormulogParser::TupleTermContext *ctx) = 0;

  virtual void enterRecordUpdateTerm(FormulogParser::RecordUpdateTermContext *ctx) = 0;
  virtual void exitRecordUpdateTerm(FormulogParser::RecordUpdateTermContext *ctx) = 0;

  virtual void enterRecordEntries(FormulogParser::RecordEntriesContext *ctx) = 0;
  virtual void exitRecordEntries(FormulogParser::RecordEntriesContext *ctx) = 0;

  virtual void enterRecordEntry(FormulogParser::RecordEntryContext *ctx) = 0;
  virtual void exitRecordEntry(FormulogParser::RecordEntryContext *ctx) = 0;

  virtual void enterLetBind(FormulogParser::LetBindContext *ctx) = 0;
  virtual void exitLetBind(FormulogParser::LetBindContext *ctx) = 0;

  virtual void enterNonEmptyTermList(FormulogParser::NonEmptyTermListContext *ctx) = 0;
  virtual void exitNonEmptyTermList(FormulogParser::NonEmptyTermListContext *ctx) = 0;

  virtual void enterList(FormulogParser::ListContext *ctx) = 0;
  virtual void exitList(FormulogParser::ListContext *ctx) = 0;

  virtual void enterTuple(FormulogParser::TupleContext *ctx) = 0;
  virtual void exitTuple(FormulogParser::TupleContext *ctx) = 0;

  virtual void enterMatchClause(FormulogParser::MatchClauseContext *ctx) = 0;
  virtual void exitMatchClause(FormulogParser::MatchClauseContext *ctx) = 0;

  virtual void enterPatterns(FormulogParser::PatternsContext *ctx) = 0;
  virtual void exitPatterns(FormulogParser::PatternsContext *ctx) = 0;


};

